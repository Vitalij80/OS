LTCMiner
========
10/10/12
  -Upload in progress